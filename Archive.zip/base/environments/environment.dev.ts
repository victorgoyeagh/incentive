export const environment = {
    production: false,
    envName: 'dev',
    uiConfig: {
        modalDefaultDimensions: {
            Height: 400,
            Width: 400
        },
        errorMessages: {
        }
    }
}; 
