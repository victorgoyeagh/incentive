export const environment = {
    production: true,
    envName: 'prod',
    uiConfig: {
        modalDefaultDimensions: {
            Height: 400,
            Width: 400
        },
        errorMessages: {
        }
    }
}; 
