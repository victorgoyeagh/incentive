
export interface IBackgroundSize {
    Width: string;
    Height: string;
}