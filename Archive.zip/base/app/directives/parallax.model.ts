export enum ParallaxDirection {
    Up = <any>'up',
    Down = <any>'down'
}
