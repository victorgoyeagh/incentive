import { Component } from '@angular/core';

@Component({
    selector: 'e-main',
    templateUrl: './templates/main.template.html'
})

export class MainComponent { 
    
    constructor() { }
 
}