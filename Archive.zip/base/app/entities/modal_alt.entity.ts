
export interface IModalReturnValue {
  ModalKey: string,
  ModalResponse: boolean,
  ModalValue: any,
  ModalFormValue: any,
  random: number
}
