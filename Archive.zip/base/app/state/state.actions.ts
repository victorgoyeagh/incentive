

export const DefaultActions = {
    DEFAULT_ACTION: "DEFAULT_ACTION"
}