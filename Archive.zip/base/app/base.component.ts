import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MenuCtrl } from './helpers/MenuCtrl';
import { ModalInfo, ModalCommand, ModalType, ModalFormType, ModalLocation } from './entities/modal.entity';
import { CommunicationService } from './services/communication.service';
import { ParallaxDirection } from './directives/parallax.model';


@Component({
    selector: 'e-root',
    templateUrl: './base.template.html'
})

export class BaseComponent implements OnInit {
    public currentYear: string = undefined;
    public ParallaxDirection = ParallaxDirection;

    constructor(
        private _communicationService: CommunicationService
    ) {
    }

    ngOnInit() {

        //apply responsive classes of menu
        new MenuCtrl("toggleBtn", "toggleNav", "toggleHeader", "toggleMain", false);

        //set year
        this.currentYear = (new Date()).getFullYear().toString();
    }

    requestQuoteForm(){
        
        let modalInfo: ModalInfo = new ModalInfo(
            `<h3>Request quote</h3>`,
            ``,
            ModalCommand.Open,
            ModalType.Alert,
            "OK",
            "",
            null,
            ModalFormType.QuoteRequestForm,
            "bookmarkModal",
            null,
            ModalLocation.Center
        );

        this._communicationService.ShareModalInfoData(modalInfo);
        
    }
 
}


