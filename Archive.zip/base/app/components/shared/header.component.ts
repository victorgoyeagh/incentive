import { Component, OnInit, Input, EventEmitter } from '@angular/core';

@Component({
    selector: 'e-header',
    templateUrl: './templates/header.template.html'
})

export class HeaderComponent implements OnInit {

    constructor(
    ) {
     
    }

    ngOnInit() {
    }
}